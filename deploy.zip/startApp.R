library(shiny)
options(shiny.host = '0.0.0.0')
options(shiny.port = 80)
runApp('app.R')
